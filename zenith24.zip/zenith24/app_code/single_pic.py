from ultralytics import YOLO

model = YOLO('/home/rohan/Downloads/Final.pt')
pic = '/home/rohan/Downloads/Johann.jpg'

results = model.predict(pic)
result = results[0]
names = result.names

for i in range(len(result.boxes)):
    box = result.boxes[i]
    print('Object: ', names[box.cls[0].item()])
    print('Coordinates: ', box.xyxy[0].tolist())
    print('Probability: ', box.conf[0].item())
